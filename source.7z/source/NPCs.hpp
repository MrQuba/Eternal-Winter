#pragma once
class NPCs {
public:
	enum Non_Playable_Characters {
		None = 0,
		Leader = 1,
		Marc = 2,
		Elf = 3
	};
};