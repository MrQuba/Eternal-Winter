#include <SFML/Graphics.hpp>
#include "Text.hpp"
#include <iostream>
#pragma once

class Interactions {
public:
	bool with_npc(sf::Sprite& player, sf::Sprite& npc, sf::RenderWindow& window, sf::Text& text);
private:
};
