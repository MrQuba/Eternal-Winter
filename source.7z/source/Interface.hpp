#include "Entity.hpp"
#include <SFML/Graphics.hpp>
#pragma once

class Interface : public Entity{
public:
};
